# Mindre saker versus overgangsfeil

**Fra:** ingrid.mork@nordflow.example
**Til:** elise.haugen@nordflow.example, ragnhild.moen@nordflow.example
**Kopi:** servicedesk@nordflow.example
**Sendt:** 2026-09-10T10:36:00+02:00
**Emne:** Mindre saker versus overgangsfeil

Fint at dere skiller årsak. Vi har et reelt OneFlow-problem i pilot og fornyelser, men den ordinære køen skal ikke brukes som bevis for at alt skyldes programmet. Fortsett med årsakskode og pilotmarkering.

Ingrid

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** elise.haugen@nordflow.example  
**Sendt:** 2026-08-27T12:22:00+02:00  
**Til:** servicedesk@nordflow.example  
**Emne:** Sv: August – nye saker over fem dager

Takk. SFTP-saken må eskaleres til kundens IT; vi har levert nøkkel og testfil. SMS-feilen ligger hos teleleverandøren. Hold begge utenfor OneFlow-rapporteringen.

Elise

---

**Fra:** servicedesk@nordflow.example  
**Sendt:** 2026-08-19T08:48:00+02:00  
**Til:** elise.haugen@nordflow.example  
**Emne:** August – nye saker over fem dager

Fire saker: to manglende kundesvar, én integrasjon mot kundens gamle SFTP og én feil i SMS-varsling. Ingen av kundene er i OneFlow-piloten.

Servicedesk

---

**Fra:** servicedesk@nordflow.example  
**Sendt:** 2026-08-11T15:03:00+02:00  
**Til:** elise.haugen@nordflow.example  
**Emne:** Sv: Ukentlig oversikt – mindre kundesaker

Vestbygg er lukket etter tømming av cache. Norplast-tilgang er også løst. Fjordvik venter fortsatt reservedel fra produsent.

Servicedesk

---

**Fra:** ragnhild.moen@nordflow.example  
**Sendt:** 2026-08-07T13:26:00+02:00  
**Til:** elise.haugen@nordflow.example  
**Emne:** Sv: Ukentlig oversikt – mindre kundesaker

Vestbygg ser gammel ordrestatus i portalen, men faktura og ordre i ERP er riktig. Feilen er i cache etter migreringen. Teamet har workaround og retter mandag.

Ragnhild

---

**Fra:** elise.haugen@nordflow.example  
**Sendt:** 2026-08-06T09:51:00+02:00  
**Til:** servicedesk@nordflow.example  
**Emne:** Sv: Ukentlig oversikt – mindre kundesaker

Ta Vestbygg med Ragnhild siden de er pilot. Resten går i vanlig kø. Ikke merk hele listen OneFlow; fem av sju er ordinære supportsaker.

Elise

---

**Fra:** servicedesk@nordflow.example  
**Sendt:** 2026-08-05T08:17:00+02:00  
**Til:** elise.haugen@nordflow.example  
**Emne:** Ukentlig oversikt – mindre kundesaker

Sju saker har stått åpne over fem virkedager: utskifting av sensor hos Fjordvik, tilgang hos Norplast, to rapportabonnement, feil kontaktperson hos Akerholm, en portalvisning hos pilotkunde Vestbygg og to bestillinger som venter kundebekreftelse.

Servicedesk

---

</details>
