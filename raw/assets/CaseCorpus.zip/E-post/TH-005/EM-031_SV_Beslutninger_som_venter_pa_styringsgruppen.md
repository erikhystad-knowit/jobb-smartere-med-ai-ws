# SV: Beslutninger som venter på styringsgruppen

**Fra:** eirik.solheim@nordflow.example
**Til:** julie.nystad@nordflow.example
**Kopi:** thomas.vik@nordflow.example, hakon.berg@nordflow.example
**Sendt:** 2026-09-12T16:00:00+02:00
**Emne:** SV: Beslutninger som venter på styringsgruppen

Jeg tar poenget, men vi må også slutte å sende uferdige alternativer til linjen. For kontraktsmodellen kan jeg gi svar fredag hvis konsekvensen for bemanning er med.

Eirik

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** julie.nystad@nordflow.example  
**Sendt:** 2026-08-22T14:45:10+02:00  
**Til:** thomas.vik@nordflow.example  
**Emne:** SV: Beslutninger som venter på styringsgruppen

Til orientering: beslutningsloggen per august viser median 35,5 kalenderdager mot mål 7. Ti av tolv kritiske saker har brukt mer enn 30 dager. Dette er nå en gjentakende avhengighet, ikke enkeltsaker.

Julie

---

**Fra:** thomas.vik@nordflow.example  
**Sendt:** 2026-08-01T13:30:20+02:00  
**Til:** julie.nystad@nordflow.example  
**Emne:** SV: Beslutninger som venter på styringsgruppen

Sett saken på ekstraordinær agenda. Håkon legger frem anbefaling, Eirik bekrefter operativ konsekvens. Dersom uenighet, avgjør styringsgruppen.

Thomas

---

**Fra:** hakon.berg@nordflow.example  
**Sendt:** 2026-07-11T12:15:30+02:00  
**Til:** eirik.solheim@nordflow.example  
**Emne:** SV: Beslutninger som venter på styringsgruppen

Programmet kan foreslå løsning, men prosesseier må akseptere driftskonsekvensen. Det er nettopp den godkjenningen vi venter på.

Håkon

---

**Fra:** julie.nystad@nordflow.example  
**Sendt:** 2026-06-02T08:41:00+02:00  
**Til:** hakon.berg@nordflow.example  
**Emne:** SV: Beslutninger som venter på styringsgruppen

Kontraktsmodell for serviceavvik ble meldt 9. mai og er fortsatt uten beslutning. Den blokkerer tre integrasjoner og representative testdata. Mandatet sier prosesseier; linjen viser til styringsgruppen. Hvem beslutter?

Julie

---

**Fra:** eirik.solheim@nordflow.example  
**Sendt:** 2026-05-30T09:45:50+02:00  
**Til:** julie.nystad@nordflow.example  
**Emne:** SV: Beslutninger som venter på styringsgruppen

Flere av disse er programbeslutninger, ikke saker for linjen. Styringsgruppen kan ikke ta stilling til hver prosessvariant.

Eirik

---

**Fra:** julie.nystad@nordflow.example  
**Sendt:** 2026-05-09T08:31:00+02:00  
**Til:** hakon.berg@nordflow.example  
**Emne:** Beslutninger som venter på styringsgruppen

Oppdatert kø før mandag: 17 åpne beslutninger, hvorav fem kritiske. Tre har passert 30 dager. Vi trenger eiere og frist, ellers påvirkes kontraktsmodell, testdata og feltplanlegging.

Julie

---

</details>
