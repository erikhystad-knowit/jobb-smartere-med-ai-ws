# SV: Beslutninger som venter på styringsgruppen

**Fra:** hakon.berg@nordflow.example
**Til:** eirik.solheim@nordflow.example
**Kopi:** julie.nystad@nordflow.example, thomas.vik@nordflow.example
**Sendt:** 2026-07-11T12:15:30+02:00
**Emne:** SV: Beslutninger som venter på styringsgruppen

Programmet kan foreslå løsning, men prosesseier må akseptere driftskonsekvensen. Det er nettopp den godkjenningen vi venter på.

Håkon

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** julie.nystad@nordflow.example  
**Sendt:** 2026-06-02T08:41:00+02:00  
**Til:** hakon.berg@nordflow.example  
**Emne:** SV: Beslutninger som venter på styringsgruppen

Kontraktsmodell for serviceavvik ble meldt 9. mai og er fortsatt uten beslutning. Den blokkerer tre integrasjoner og representative testdata. Mandatet sier prosesseier; linjen viser til styringsgruppen. Hvem beslutter?

Julie

---

**Fra:** eirik.solheim@nordflow.example  
**Sendt:** 2026-05-30T09:45:50+02:00  
**Til:** julie.nystad@nordflow.example  
**Emne:** SV: Beslutninger som venter på styringsgruppen

Flere av disse er programbeslutninger, ikke saker for linjen. Styringsgruppen kan ikke ta stilling til hver prosessvariant.

Eirik

---

**Fra:** julie.nystad@nordflow.example  
**Sendt:** 2026-05-09T08:31:00+02:00  
**Til:** hakon.berg@nordflow.example  
**Emne:** Beslutninger som venter på styringsgruppen

Oppdatert kø før mandag: 17 åpne beslutninger, hvorav fem kritiske. Tre har passert 30 dager. Vi trenger eiere og frist, ellers påvirkes kontraktsmodell, testdata og feltplanlegging.

Julie

---

</details>
