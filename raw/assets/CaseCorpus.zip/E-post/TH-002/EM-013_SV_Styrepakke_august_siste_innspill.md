# SV: Styrepakke august – siste innspill

**Fra:** hakon.berg@nordflow.example
**Til:** julie.nystad@nordflow.example
**Kopi:** thomas.vik@nordflow.example, camilla.bruun@nordflow.example
**Sendt:** 2026-08-24T16:00:00+02:00
**Emne:** SV: Styrepakke august – siste innspill

Godkjent med de endringene. Hold budskapet kort: gul/stabiliserende, kontrollert kundebølge og tydelig leverandøroppfølging. Vi tar detaljene muntlig dersom styret spør.

Håkon

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** thomas.vik@nordflow.example  
**Sendt:** 2026-08-23T10:50:30+02:00  
**Til:** hakon.berg@nordflow.example  
**Emne:** SV: Styrepakke august – siste innspill

Kostnadsprognosen settes til 395 i styrepakken. Interne scenarioer er ikke ferdig kontrollert og leverandørkreditt er uavklart. Legg inn at ytterligere risiko vurderes i september.

Thomas

---

**Fra:** julie.nystad@nordflow.example  
**Sendt:** 2026-08-22T08:41:00+02:00  
**Til:** hakon.berg@nordflow.example  
**Emne:** SV: Styrepakke august – siste innspill

Jeg har beholdt data/migrering som rød i arbeidsstrømtabellen og samlet status gul etter din instruks. Fotnoten sier at fremdrift måles mot recovery baseline. Originalplanen er nå vedlegg 4.

Julie

---

**Fra:** hakon.berg@nordflow.example  
**Sendt:** 2026-08-21T10:14:00+02:00  
**Til:** julie.nystad@nordflow.example  
**Emne:** SV: Styrepakke august – siste innspill

Bruk gul på totalen. Skriv at første kontrollerte bølge er avgrenset til 42 kunder for å beskytte kvalitet. Det er en styrt sekvensering, ikke en kansellering av bølgen. Flytt originalplansammenlikningen til vedlegget slik vi gjorde i juni.

Håkon

---

**Fra:** ragnhild.moen@nordflow.example  
**Sendt:** 2026-08-19T19:22:00+02:00  
**Til:** julie.nystad@nordflow.example  
**Emne:** SV: Styrepakke august – siste innspill

Bølgen er redusert fra 286 til 42 kunder. Det er riktig grep, men da bør vi ikke skrive ‘utrulling i henhold til plan’. Vi har også lagt inn manuell fakturakontroll for alle 42.

Ragnhild

---

**Fra:** camilla.bruun@nordflow.example  
**Sendt:** 2026-08-18T14:12:30+02:00  
**Til:** julie.nystad@nordflow.example  
**Emne:** SV: Styrepakke august – siste innspill

Data/migrering er rød. 14 av 27 kritiske objekter består, duplikatgrad er 11,7 %, og fakturamottaker er uavklart i flere aktive kontrakter. Jeg kan ikke stå inne for formuleringen ‘følger plan’.

Camilla

---

**Fra:** julie.nystad@nordflow.example  
**Sendt:** 2026-08-17T09:03:00+02:00  
**Til:** hakon.berg@nordflow.example  
**Emne:** Styrepakke august – siste innspill

Vedlagt arbeidsversjon. Jeg mangler eksplisitt farge og kommentar fra data/migrering og kundeovergang innen kl. 14. Sammenlikningen mot originalplan ligger foreløpig i hoveddelen.

Julie

---

</details>
