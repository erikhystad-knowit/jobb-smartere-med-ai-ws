# SV: Cobalt datakvalitet – fortsatt rødt

**Fra:** mikkel.sorensen@nordflow.example
**Til:** camilla.bruun@nordflow.example
**Kopi:** hakon.berg@nordflow.example, lars.pettersen@nordflow.example
**Sendt:** 2026-07-18T14:55:00+02:00
**Emne:** SV: Cobalt datakvalitet – fortsatt rødt

Vi kan stille to lokale specialister til rådighed i august, men de er også nødvendige i driften. Planen må tage højde for ferie og kundernes indekskørsler.

Mikkel

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** camilla.bruun@nordflow.example  
**Sendt:** 2026-06-03T13:50:00+02:00  
**Til:** hakon.berg@nordflow.example  
**Emne:** SV: Cobalt datakvalitet – fortsatt rødt

Status juni: 16 av 27 kritiske objekter består. Fremdriften er bedre, men kontrakts- og kundedata er fortsatt blant de som feiler. Jeg opprettholder rød.

Camilla

---

**Fra:** hakon.berg@nordflow.example  
**Sendt:** 2026-04-19T12:45:00+02:00  
**Til:** camilla.bruun@nordflow.example  
**Emne:** SV: Cobalt datakvalitet – fortsatt rødt

Registrer risiko gul/rød med tiltak. Vi endrer ikke hovedmilepæl før dere har estimert rensing og automatisk treffprosent.

Håkon

---

**Fra:** camilla.bruun@nordflow.example  
**Sendt:** 2026-03-05T11:40:00+01:00  
**Til:** lars.pettersen@nordflow.example  
**Emne:** SV: Cobalt datakvalitet – fortsatt rødt

Full profiling viser 12,4 % duplikater. Akseptansekriteriet er under 2 %. Dette kan ikke ryddes ‘i flyten’ uten kontrollert matching og virksomhetsgodkjenning.

Camilla

---

**Fra:** lars.pettersen@nordflow.example  
**Sendt:** 2026-01-19T10:35:00+01:00  
**Til:** camilla.bruun@nordflow.example  
**Emne:** SV: Cobalt datakvalitet – fortsatt rødt

Begge deler er sant. Datakvaliteten er svak, men målmodellen mangler også beslutninger. Vi må skille kildefeil fra manglende mapping.

Lars

---

**Fra:** mikkel.sorensen@nordflow.example  
**Sendt:** 2025-12-05T09:30:00+01:00  
**Til:** camilla.bruun@nordflow.example  
**Emne:** SV: Cobalt datakvalitet – fortsatt rødt

Det er kendte forhold, men den lokale fakturering fungerer i dag. Problemet opstår især fordi OneFlow kræver én struktur før alle kontraktvarianter er modelleret.

Mikkel

---

**Fra:** camilla.bruun@nordflow.example  
**Sendt:** 2025-10-21T08:26:00+02:00  
**Til:** mikkel.sorensen@nordflow.example  
**Emne:** Cobalt datakvalitet – fortsatt rødt

Før full profiling: kundemasteren har flere dublettmønstre og fakturamottaker ligger dels i fritekst. Dette ble også varslet da profileringen bare var 22 % ferdig. Vi bør ikke låse migreringsdato før hele uttrekket er analysert.

Camilla

---

</details>
