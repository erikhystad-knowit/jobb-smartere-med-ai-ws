# Anbefaling: kontrollert reset

**Fra:** amina.rahman@nordflow.example
**Til:** karin.eide@nordflow.example, amina.rahman@nordflow.example, eirik.solheim@nordflow.example, hakon.berg@nordflow.example
**Kopi:** –
**Sendt:** 2026-09-16T07:50:00+02:00
**Emne:** Anbefaling: kontrollert reset

**Vedlegg:** CIO_Technical_Review_OneFlow_draft.md, OneFlow_prognose_16092026_kontrollert.csv

Min anbefaling står: behold teknisk kjerne, skyv avansert planlegging, fase portalen og stans nye ikke-regulatoriske tillegg. Fire uker brukes til beslutningsrettigheter, data-/testporter, kapasitet og troverdig plan.

Dette må være et konsernreset, ikke et IT-reset. Governance, gevinststyring og kunde-/inntektskontroll må inngå, og styret må se korrekt kostnadsintervall.

Amina

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** thomas.vik@nordflow.example  
**Sendt:** 2026-09-15T09:42:00+02:00  
**Til:** karin.eide@nordflow.example, amina.rahman@nordflow.example, eirik.solheim@nordflow.example, hakon.berg@nordflow.example  
**Emne:** Sv: Beslutningsalternativer for OneFlow

Finance har sett på full stopp. Det utløser avvikling, kontraktskost og minst to år med dobbelt systemlandskap. Det kan være riktig hvis kjernen er ubrukelig, men Aminas review sier det motsatte.

Kontrollert reset må vurderes mot oppdatert NPV, ikke forsvares med sunk cost. Fortsette uendret ser samtidig ut til å ha høyest gjennomføringsrisiko.

Thomas

---

**Fra:** eirik.solheim@nordflow.example  
**Sendt:** 2026-09-14T16:11:00+02:00  
**Til:** amina.rahman@nordflow.example, thomas.vik@nordflow.example, hakon.berg@nordflow.example  
**Emne:** Sv: Beslutningsalternativer for OneFlow

Jeg støtter redusert kjerne, men kundedrift må få finansiert backfill før vi låser folk til programmet. Full stopp løser ikke dobbeltdriften i linjen. Dagens modell er heller ikke holdbar; vi tar kostnaden begge steder uten å få kontroll.

Eirik

---

**Fra:** hakon.berg@nordflow.example  
**Sendt:** 2026-09-10T14:18:00+02:00  
**Til:** amina.rahman@nordflow.example, thomas.vik@nordflow.example, eirik.solheim@nordflow.example  
**Emne:** Sv: Beslutningsalternativer for OneFlow

Hvis reset velges må den være finansiert og faktisk slutte etter fire uker. Det er mulig dersom styringsgruppen beslutter scope samme uke og linjen leverer navngitte folk.

Jeg vil advare mot at en kontrollert reset glir over i en generell pause og ny mobilisering.

Håkon

---

**Fra:** amina.rahman@nordflow.example  
**Sendt:** 2026-09-10T08:32:00+02:00  
**Til:** thomas.vik@nordflow.example, eirik.solheim@nordflow.example, hakon.berg@nordflow.example  
**Emne:** Sv: Beslutningsalternativer for OneFlow

Jeg har konkretisert alternativ 3: fire ukers kontrollert reset, ikke en generell pause. Kjerneplattform og basisintegrasjoner beholdes; ikke-obligatoriske forbedringer fryses mens prosesseiere, data-/testporter og navngitt kapasitet låses.

Exit er et besluttet redusert omfang og en plan som kan etterprøves mot forretningsgodkjenning, ikke bare teknisk klar til test.

Amina

---

**Fra:** amina.rahman@nordflow.example  
**Sendt:** 2026-09-09T15:05:00+02:00  
**Til:** thomas.vik@nordflow.example, eirik.solheim@nordflow.example, hakon.berg@nordflow.example  
**Emne:** Beslutningsalternativer for OneFlow

Jeg foreslår at vi sammenligner tre reelle alternativer: 1) fortsette dagens modell, 2) full stopp, 3) fire ukers kontrollert reset med redusert kjerne.

Mitt utgangspunkt er alternativ 3. Det gir tid til å fryse ikke-obligatorisk scope, etablere portkriterier og låse navngitt kapasitet uten å demontere plattformen.

Amina

---

</details>
