# Sv: Bankmøte 25. september – underlag

**Fra:** thomas.vik@nordflow.example
**Til:** treasury@nordflow.example
**Kopi:** karin.eide@nordflow.example
**Sendt:** 2026-09-14T09:17:00+02:00
**Emne:** Sv: Bankmøte 25. september – underlag

Takk. Jeg ønsker at vi avklarer kreditt og scope før vi formelt rebaselinerer. En ny prognose rett før bankmøtet uten besluttet tiltakspakke vil skape flere spørsmål enn svar.

Dette er ikke en instruks om å skjule risiko: sensitiviteten skal ligge i internt underlag, og Karin skal orienteres når tallene er kontrollert.

Thomas

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** treasury@nordflow.example  
**Sendt:** 2026-09-03T14:20:00+02:00  
**Til:** thomas.vik@nordflow.example  
**Emne:** Sv: Bankmøte 25. september – underlag

Foreløpig modell viser at vi holder oss innenfor covenant også ved 470, men headroom blir merkbart lavere i Q1/Q2 dersom gevinstuttaket skyves. Banken vil trolig spørre om styregodkjent rebaseline og leverandørkravet.

Vi trenger ett konsistent tallsett senest 18. september.

Mona / Treasury

---

**Fra:** thomas.vik@nordflow.example  
**Sendt:** 2026-08-26T08:55:00+02:00  
**Til:** treasury@nordflow.example  
**Emne:** Bankmøte 25. september – underlag

Vi trenger oppdatert covenant-headroom, likviditetsbane og sensitivitet for OneFlow før bankmøtet. Bruk 395 som godkjent forecast, men ha en separat sensitivitet for utfallsrommet som Finance nå arbeider med.

Ikke send eksternt før jeg har sett helheten.

Thomas

---

</details>
