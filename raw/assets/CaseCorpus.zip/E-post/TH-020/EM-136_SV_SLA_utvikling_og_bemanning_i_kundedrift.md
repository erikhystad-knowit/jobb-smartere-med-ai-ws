# SV: SLA-utvikling og bemanning i kundedrift

**Fra:** ingrid.mork@nordflow.example
**Til:** eirik.solheim@nordflow.example, hakon.berg@nordflow.example
**Kopi:** elise.haugen@nordflow.example, johan.ek@nordflow.example
**Sendt:** 2026-08-11T07:41:00+02:00
**Emne:** SV: SLA-utvikling og bemanning i kundedrift

Dette er ikke lenger midlertidig. Juli-SLA er 92,1 prosent og svartid 119 sekunder. Køen er størst i Norge og Danmark, der vi har avgitt flest kontrakts- og prosesseksperter. Fravær og høyere volum bidrar også, men ressursuttaket er tydelig i vaktplanene.

Ingrid

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** eirik.solheim@nordflow.example  
**Sendt:** 2026-01-26T07:23:00+01:00  
**Til:** ingrid.mork@nordflow.example, hakon.berg@nordflow.example  
**Emne:** SV: SLA-utvikling og bemanning i kundedrift

Ikke frigi alle ni før vi har vaktplanen dekket. Programmet må ta høyde for at linjen har leveranseansvar. Håkon, finn en sekvens med fem nå og resten etter vinterferien.

Eirik

---

**Fra:** ingrid.mork@nordflow.example  
**Sendt:** 2026-01-25T18:11:00+01:00  
**Til:** eirik.solheim@nordflow.example, hakon.berg@nordflow.example  
**Emne:** SLA-utvikling og bemanning i kundedrift

Januar endte på 95,8 prosent SLA og 48 sekunder svartid. Vi leverer fortsatt, men februarplanen tar ytterligere ni fagpersoner inn i OneFlow-test. Jeg trenger bekreftet backfill før de frigis.

Ingrid

---

</details>
