# SV: Representative test data missing

**Fra:** lars.pettersen@nordflow.example
**Til:** hakon.berg@nordflow.example
**Kopi:** camilla.bruun@nordflow.example, kjetil.borge@nordflow.example
**Sendt:** 2026-06-21T17:14:00+02:00
**Emne:** SV: Representative test data missing

Håkon, vi må være ryddige i leverandøreskaleringen. Representative data kom komplett 17. juni, altså over tre uker etter avtalt dato. Convergent har egne feil, men akkurat dette testvinduet ble blokkert av oss.

Lars

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** camilla.bruun@nordflow.example  
**Sendt:** 2026-05-18T10:02:00+02:00  
**Til:** eleanor.price@synervia.example, lars.pettersen@nordflow.example  
**Emne:** SV: Representative test data missing

Det danske uttrekket er forsinket fordi kontraktsfamiliene ikke er ferdig klassifisert. Vi kan levere anonymiserte rådata fredag, men forventer at dere bidrar til mappingen; dette var ikke ment som en ferdig fasit fra Nordflow.

Camilla

---

**Fra:** eleanor.price@synervia.example  
**Sendt:** 2026-05-18T08:37:00+02:00  
**Til:** lars.pettersen@nordflow.example, camilla.bruun@nordflow.example  
**Emne:** Representative test data missing

We cannot complete regression for billing and contract migration with the current sample. It has no Danish index-linked contracts, no Swedish split invoices and only two historical amendments. Please provide a representative set by 25 May or the June test window will move.

Eleanor

---

</details>
