# Sv: Prisindeks i migrerte avtaler

**Fra:** beate.hoyer@nordflow.example
**Til:** mari.heggen@nordflow.example, thomas.vik@nordflow.example
**Kopi:** silje.tran@nordflow.example
**Sendt:** 2026-09-12T13:21:00+02:00
**Emne:** Sv: Prisindeks i migrerte avtaler

**Vedlegg:** Kundefornyelser_risikorapport_12092026.csv

Takk. Dette må skilles tydelig i tre kategorier: bekreftet kreditering, sannsynlig kontraktskrav og usikker dataobservasjon. Vi skal ikke omtale 8,9 som tap.

Kan dere samtidig flagge hvilke av de fem fornyelseskundene som er berørt? Jeg vil unngå at en teknisk kontrollsak blir en kommersiell overraskelse.

Beate

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** mari.heggen@nordflow.example  
**Sendt:** 2026-09-12T09:06:00+02:00  
**Til:** beate.hoyer@nordflow.example, thomas.vik@nordflow.example  
**Emne:** Sv: Prisindeks i migrerte avtaler

Thomas og Beate,

Første kontraktsmessige beregning gir mulig eksponering på 8,9 mill. kroner. Dette er et øvre arbeidsestimat, ikke bokført tap. Det består av feil/manglende prisregulering, mulige servicekreditter og avtaler der kontrollgrunnlaget ikke er komplett.

Viktig: 1,7 mill. gjelder de samme kundesakene som allerede ligger i krediteringslisten fra regnskap. Det må trekkes fra dersom noen lager et samlet tall. Resterende mulig, ytterligere tapsrisiko er dermed inntil 7,2 mill.

Mari

---

**Fra:** sander.lie@nordflow.example  
**Sendt:** 2026-09-02T15:44:00+02:00  
**Til:** mari.heggen@nordflow.example, ragnhild.moen@nordflow.example  
**Emne:** Sv: Prisindeks i migrerte avtaler

Har kjørt uttrekket. 42 pilotkunder, 61 aktive avtaler. 13 avtaler har enten tom basisdato, avvikende indekskode eller manglende SLA-regel. Det betyr ikke at alle er feilfakturert.

Jeg legger ved datakvalitetsrapporten siden samme avtaler også har høyere andel tvetydig fakturamottaker.

Sander

---

**Fra:** mari.heggen@nordflow.example  
**Sendt:** 2026-08-31T09:12:00+02:00  
**Til:** ragnhild.moen@nordflow.example, sander.lie@nordflow.example  
**Emne:** Prisindeks i migrerte avtaler

Hei,

Vi har kontrollert de første 18 migrerte avtalene. Seks har prisindeks lagret uten basisdato, og på to avtaler er servicekreditt-tabellen ikke kommet med. Foreløpig er beløpene små, men mønsteret gjør at jeg vil utvide kontrollen før neste bølge.

Sander: kan du trekke alle aktive pilotavtaler med saksnummer og siste kreditering?

Mari

---

</details>
