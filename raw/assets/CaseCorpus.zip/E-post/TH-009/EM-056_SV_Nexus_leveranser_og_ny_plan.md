# SV: Nexus leveranser og ny plan

**Fra:** lars.pettersen@nordflow.example
**Til:** eleanor.price@synervia.example
**Kopi:** hakon.berg@nordflow.example, ole.martin.kvale@nordflow.example
**Sendt:** 2026-06-13T09:30:00+02:00
**Emne:** SV: Nexus leveranser og ny plan

Verktøyet kom i dag, men feiler på nordisk fakturavariant og volumkjøring. Vi kan starte begrenset test, ikke lukke milepælen. Mateo og Kjetil tar triage kl. 13.

Lars

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** eleanor.price@synervia.example  
**Sendt:** 2026-05-06T16:07:00+02:00  
**Til:** ole.martin.kvale@nordflow.example  
**Emne:** SV: Nexus leveranser og ny plan

We confirm that the deployable migration utility is five weeks late. Architect continuity and defects are Convergent responsibilities. Eleven design decisions also arrived 4–9 weeks late, so this notice should not be read as the sole cause of programme delay.

Eleanor

---

**Fra:** ole.martin.kvale@nordflow.example  
**Sendt:** 2026-04-24T14:35:00+02:00  
**Til:** eleanor.price@synervia.example  
**Emne:** SV: Nexus leveranser og ny plan

Vi registrerer fem ukers leverandørforsinkelse. Varslet skyldes ikke bare testdata; kontrakten forutsetter bemannet arkitektteam og kontinuitet, og dere har nå byttet løsningsarkitekt to ganger.

Ole

---

**Fra:** eleanor.price@synervia.example  
**Sendt:** 2026-04-10T10:12:00+02:00  
**Til:** lars.pettersen@nordflow.example  
**Emne:** SV: Nexus leveranser og ny plan

We acknowledge the delay. The deployable migration utility is now forecast for 6 May, five weeks late. We have added engineering capacity, but stable mapping rules and representative test data remain customer dependencies.

Eleanor

---

**Fra:** lars.pettersen@nordflow.example  
**Sendt:** 2026-04-03T09:42:00+02:00  
**Til:** eleanor.price@synervia.example  
**Emne:** Nexus leveranser og ny plan

Nexus migreringsverktøy skulle vært i test 31. mars. Vi har ikke en kjørbar pakke eller ny bindende dato. Dette ligger på kritisk sti for bølge 1. Kan dere bekrefte recovery innen mandag?

Lars

---

</details>
