# Fwd: Aurora – foreløpige funn

**Fra:** sofia.lindberg@nordflow.example
**Til:** partner@aurora-sensors.example
**Kopi:** security@nordflow.example
**Sendt:** 2026-08-05T08:16:00+02:00
**Emne:** Fwd: Aurora – foreløpige funn

Hei,

Se punktene under. Kan dere bekrefte dato for MFA og sende slettesertifikat for testmiljøet? Vi vil beholde pilotdato dersom dette lukkes innen 20. august.

Sofia

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** security@nordflow.example  
**Sendt:** 2026-08-04T14:22:00+02:00  
**Til:** sofia.lindberg@nordflow.example  
**Emne:** Aurora – foreløpige funn

Tre funn: loggingstid er for kort, leverandørtilgang mangler MFA for én supportflate, og sletting av testdata er ikke dokumentert. Ingen kritiske funn, men MFA må lukkes før pilot.

Security

---

**Fra:** security@nordflow.example  
**Sendt:** 2026-07-06T09:42:00+02:00  
**Til:** sofia.lindberg@nordflow.example  
**Emne:** Sv: Project Aurora – behov for sikkerhetsgjennomgang

Ja. Send dataflyt, underleverandørliste og beskrivelse av fjernaksess. Vi reserverer uke 31. Delt arkitekt er en planleggingsrisiko, ikke en sikkerhetsrisiko.

Mvh Security

---

**Fra:** sofia.lindberg@nordflow.example  
**Sendt:** 2026-07-03T13:15:00+02:00  
**Til:** security@nordflow.example  
**Emne:** Project Aurora – behov for sikkerhetsgjennomgang

Vi planlegger begrenset pilot av sensorplattformen i september. Kan Security gjøre trusselmodell og leverandørvurdering før 15. august? Aurora er gul pga. kapasitet, men har ingen avhengighet til OneFlow utover én delt arkitekt.

Sofia

---

</details>
