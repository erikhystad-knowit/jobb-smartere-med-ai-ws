# SV: Bemanning i programmet – ukeplan

**Fra:** henrik.dahl@nordflow.example
**Til:** hakon.berg@nordflow.example, lene.falk@nordflow.example
**Kopi:** eirik.solheim@nordflow.example, amina.rahman@nordflow.example
**Sendt:** 2026-08-27T15:46:00+02:00
**Emne:** SV: Bemanning i programmet – ukeplan

Kritisk de neste åtte ukene er 12 dataspesialister, 7 integrasjon/test og 4 prosesseksperter. Vi kan fylle noen roller eksternt, men ikke lokalkunnskap om kontrakter og gamle grensesnitt. Tolv nøkkelpersoner har sluttet siden januar, fem innen data/integrasjon.

Henrik

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** hakon.berg@nordflow.example  
**Sendt:** 2026-08-24T11:02:00+02:00  
**Til:** henrik.dahl@nordflow.example, lene.falk@nordflow.example  
**Emne:** SV: Bemanning i programmet – ukeplan

Dette forklarer en vesentlig del av gjennomføringsgapet. Kan dere også vise hvilke av de 49 som er kritisk sti de neste åtte ukene? Et samlet tall gjør det for enkelt for linjen å svare at alle har knapphet.

Håkon

---

**Fra:** henrik.dahl@nordflow.example  
**Sendt:** 2026-08-24T09:28:00+02:00  
**Til:** hakon.berg@nordflow.example, lene.falk@nordflow.example  
**Emne:** SV: Bemanning i programmet – ukeplan

Ny kapasitetsavstemming for uke 35: plan 168, tilgjengelig 119, altså gap 49. Fordelt: 21 data/integrasjon, 18 prosess/test og 10 endring/opplæring. Dette er et øyeblikksbilde av tilgjengelig kapasitet, ikke et periodegjennomsnitt eller bare ubesatte stillinger.

Henrik

---

**Fra:** lene.falk@nordflow.example  
**Sendt:** 2026-03-01T16:12:00+01:00  
**Til:** hakon.berg@nordflow.example, henrik.dahl@nordflow.example  
**Emne:** SV: Bemanning i programmet – ukeplan

37 navngitte personer har nå samlet planlagt belastning over 120 prosent. Det er ikke bare en regnefeil; lederne forventer leveranser begge steder. Fem har sluttet siden høsten. Jeg ber om en prioriteringsbeslutning, ikke enda en frivillig avstemming.

Lene

---

**Fra:** hakon.berg@nordflow.example  
**Sendt:** 2026-02-09T07:37:00+01:00  
**Til:** henrik.dahl@nordflow.example, lene.falk@nordflow.example  
**Emne:** SV: Bemanning i programmet – ukeplan

Enig i prinsippet. Samtidig er noe av gapet timing; linjen har lovet innfasing etter vintertoppen. Skill mellom ikke-navngitt kapasitet, forsinket oppstart og faktisk trukket ressurs.

Håkon

---

**Fra:** henrik.dahl@nordflow.example  
**Sendt:** 2026-02-08T19:04:00+01:00  
**Til:** hakon.berg@nordflow.example, lene.falk@nordflow.example  
**Emne:** Bemanning i programmet – ukeplan

Hei,

Ukeplanen summerer til 168 interne FTE ved topp, men bekreftede allokeringer er 126. Flere navn står både i linjeplanen og programplanen. Vi bør slutte å telle en 50-prosentressurs som tilgjengelig i begge miljøer.

Henrik

---

</details>
