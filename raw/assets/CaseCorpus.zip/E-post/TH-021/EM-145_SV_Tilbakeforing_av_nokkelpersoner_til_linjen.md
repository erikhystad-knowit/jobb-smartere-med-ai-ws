# SV: Tilbakeføring av nøkkelpersoner til linjen

**Fra:** hakon.berg@nordflow.example
**Til:** eirik.solheim@nordflow.example, ingrid.mork@nordflow.example, lene.falk@nordflow.example
**Kopi:** thomas.vik@nordflow.example
**Sendt:** 2026-08-22T13:29:00+02:00
**Emne:** SV: Tilbakeføring av nøkkelpersoner til linjen

Siden mai har tilbakeføringer kostet estimert seks uker i data/test, samtidig som drift fortsatt er presset. Jeg ber om én konsernbeslutning: skjerm kritiske roller med finansiert backfill, eller flytt programdatoen. Dagens mellomløsning er ikke troverdig.

Håkon

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** ingrid.mork@nordflow.example  
**Sendt:** 2026-07-01T09:01:00+02:00  
**Til:** eirik.solheim@nordflow.example, hakon.berg@nordflow.example  
**Emne:** SV: Tilbakeføring av nøkkelpersoner til linjen

Jeg støtter uttaket operativt, men vi må være ærlige om følgen: vi flytter problemet, ikke løser det. De samme personene trengs for å rette årsakene til flere av sakene i køen. Kan vi låse to dager per uke til programmet?

Ingrid

---

**Fra:** eirik.solheim@nordflow.example  
**Sendt:** 2026-07-01T07:15:00+02:00  
**Til:** hakon.berg@nordflow.example, ingrid.mork@nordflow.example  
**Emne:** SV: Tilbakeføring av nøkkelpersoner til linjen

Vi tar testressursene tilbake igjen fra torsdag. Køen i kundedrift har passert 1 900 saker, og innleide kan ikke vurdere gamle avtaler. Dette er ikke forhandling. Hvis programmet trenger skjermet kapasitet, må styringsgruppen finansiere faktisk backfill.

Eirik

---

**Fra:** hakon.berg@nordflow.example  
**Sendt:** 2026-05-11T08:12:00+02:00  
**Til:** eirik.solheim@nordflow.example  
**Emne:** SV: Tilbakeføring av nøkkelpersoner til linjen

Tre testressurser er eneste personer som kan verifisere historiske kontraktsvarianter. Tar vi dem ut, flyttes fakturaregresjon minst to uker. Kan vi beholde dem på 50 prosent og kjøpe operativ backfill?

Håkon

---

**Fra:** eirik.solheim@nordflow.example  
**Sendt:** 2026-05-11T06:58:00+02:00  
**Til:** ingrid.mork@nordflow.example, hakon.berg@nordflow.example  
**Emne:** Tilbakeføring av nøkkelpersoner til linjen

Fra mandag tar vi tilbake fire kundespesialister og tre testressurser i minimum tre uker. SLA og ordrebeholdning gir oss ikke noe valg. Jeg forstår at dette treffer testplanen, men linjeleveransen går først.

Eirik

---

</details>
