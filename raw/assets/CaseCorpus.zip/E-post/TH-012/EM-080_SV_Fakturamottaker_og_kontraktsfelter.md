# SV: Fakturamottaker og kontraktsfelter

**Fra:** mari.heggen@nordflow.example
**Til:** jonas.aas@nordflow.example
**Kopi:** ragnhild.moen@nordflow.example, camilla.bruun@nordflow.example
**Sendt:** 2026-09-07T16:00:00+02:00
**Emne:** SV: Fakturamottaker og kontraktsfelter

Kontraktsforvaltning kan validere høyrisikosakene. Vi bør også kontrollere prisindeks og servicekreditt; mottakerfeltet er bare én del. Jeg har foreløpig ikke et samlet eksponeringsbeløp.

Mari

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** jonas.aas@nordflow.example  
**Sendt:** 2026-09-01T15:03:00+02:00  
**Til:** ragnhild.moen@nordflow.example  
**Emne:** SV: Fakturamottaker og kontraktsfelter

Finans kan følge fakturakø og DSO, men kan ikke avgjøre riktig mottaker uten kontraktsgrunnlag. Vi trenger én avstemmingsliste på tvers av ordre, kontrakt og faktura.

Jonas

---

**Fra:** ragnhild.moen@nordflow.example  
**Sendt:** 2026-08-26T14:07:00+02:00  
**Til:** camilla.bruun@nordflow.example  
**Emne:** SV: Fakturamottaker og kontraktsfelter

Vi legger alle 42 pilotkunder i manuell fakturakontroll. Det er håndterbart for piloten, men ikke for 286 kunder. Hvem eier avvik etter overføring til drift?

Ragnhild

---

**Fra:** camilla.bruun@nordflow.example  
**Sendt:** 2026-08-20T13:11:00+02:00  
**Til:** ragnhild.moen@nordflow.example  
**Emne:** Fakturamottaker og kontraktsfelter

Profileringen viser at fakturamottaker mangler eller er tvetydig i 8,4 % av aktive Cobalt-kontrakter. Før bølge 1 må disse enten rettes eller legges i manuell kontroll.

Camilla

---

</details>
