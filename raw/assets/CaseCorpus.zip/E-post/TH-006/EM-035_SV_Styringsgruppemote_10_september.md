# SV: Styringsgruppemøte 10. september

**Fra:** julie.nystad@nordflow.example
**Til:** thomas.vik@nordflow.example
**Kopi:** hakon.berg@nordflow.example, amina.rahman@nordflow.example
**Sendt:** 2026-09-09T10:03:00+02:00
**Emne:** SV: Styringsgruppemøte 10. september

Før møtet trenger vi avklart hvem som kan beslutte scope-frys. Programmandatet legger leveranseomfang til styringsgruppen, mens flere prosesseiere mener nødvendige lokale varianter ligger hos dem. Det har allerede utsatt reset-notatet.

Julie

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** eirik.solheim@nordflow.example  
**Sendt:** 2026-09-08T13:38:00+02:00  
**Til:** thomas.vik@nordflow.example  
**Emne:** SV: Styringsgruppemøte 10. september

Drift kan ikke avgi flere folk nå. SLA er 91,4 og køen vokser. En reset uten tilbakeføring av ressurser løser ikke kundeproblemet.

Eirik

---

**Fra:** amina.rahman@nordflow.example  
**Sendt:** 2026-09-07T16:46:00+02:00  
**Til:** thomas.vik@nordflow.example  
**Emne:** SV: Styringsgruppemøte 10. september

Min anbefaling er fire ukers kontrollert reset og scope-frys for forbedringer. Det er ikke teknisk forsvarlig å videreføre alle løp parallelt mens data og prosessporter er åpne.

Amina

---

**Fra:** thomas.vik@nordflow.example  
**Sendt:** 2026-09-07T07:54:00+02:00  
**Til:** hakon.berg@nordflow.example  
**Emne:** Styringsgruppemøte 10. september

Agenda torsdag: status, leverandørkrav, ressurser og mulig reset. Vi skal ende med beslutninger, ikke bare nye analyser. Håkon sender anbefaling tirsdag.

Thomas

---

</details>
