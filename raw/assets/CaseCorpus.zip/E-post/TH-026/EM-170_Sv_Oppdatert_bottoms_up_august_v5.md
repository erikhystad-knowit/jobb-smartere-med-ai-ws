# Sv: Oppdatert: bottoms-up august v5

**Fra:** thomas.vik@nordflow.example
**Til:** silje.tran@nordflow.example, hakon.berg@nordflow.example
**Kopi:** julie.nystad@nordflow.example
**Sendt:** 2026-08-21T07:46:00+02:00
**Emne:** Sv: Oppdatert: bottoms-up august v5

Jeg ser gapet. Før styrepakken er vi ikke ferdige med kredittkravet, scope-beslutningen eller kapasitetsplanen. Derfor beholder vi 395 som godkjent prognose, men styrker risikoteksten og tar ny gjennomgang etter august close.

Silje: lås definisjonene slik at vi ikke blander programkost, linjekost og tapsrisiko.

Thomas

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** silje.tran@nordflow.example  
**Sendt:** 2026-08-18T18:02:00+02:00  
**Til:** thomas.vik@nordflow.example, hakon.berg@nordflow.example  
**Emne:** Oppdatert: bottoms-up august v5

August v5 er ferdig. Base er foreløpig 459 mill. før siste avklaring av stabiliseringsperioden. Lav/høy ligger på 455/494. Det er fortsatt 34 mill. leverandørkreditt i nettoanslaget, selv om bare en del er kontraktsmessig robust.

Jeg anbefaler at vi ikke fortsetter å presentere 395 uten samtidig å vise denne broen.

Silje

---

**Fra:** hakon.berg@nordflow.example  
**Sendt:** 2026-06-18T08:14:00+02:00  
**Til:** silje.tran@nordflow.example, thomas.vik@nordflow.example  
**Emne:** Sv: Bottoms-up prognose – trenger avgrensning

Takk. Vi må holde fra hverandre styringsprognose og summen av alle identifiserte risikoer. Flere av postene i 438 har verken beslutning, bestilling eller finansiering.

Til styret bruker vi godkjent forecast med tydelig risikointervall. Bottoms-up er nyttig internt i recovery-arbeidet.

Håkon

---

**Fra:** silje.tran@nordflow.example  
**Sendt:** 2026-06-17T16:28:00+02:00  
**Til:** hakon.berg@nordflow.example, thomas.vik@nordflow.example  
**Emne:** Sv: Bottoms-up prognose – trenger avgrensning

Arbeidsfilen er nå på 438 mill. netto. Forskjellen mot det som står i styrepakken gjelder hovedsakelig forlengelse, datarydding/test og stabilisering. Jeg har fortsatt lagt inn forventet leverandørkreditt.

Vedlagt arbeidsfil. Ark «bro» viser definisjonene. Dette er et estimat, men 382 er etter mitt syn ikke lenger et forventningsrett estimat.

Silje

---

**Fra:** silje.tran@nordflow.example  
**Sendt:** 2026-06-10T11:03:00+02:00  
**Til:** hakon.berg@nordflow.example, thomas.vik@nordflow.example  
**Emne:** Bottoms-up prognose – trenger avgrensning

Hei,

Jeg har startet en bottoms-up basert på faktisk kost, inngåtte forpliktelser og arbeidsstrømmenes egne restestimater. Første gjennomløp peker mot 430–445, avhengig av hvor mye forlengelse vi legger inn.

Dette er ikke sammenlignbart med 382 før vi har avklart kreditter og hvilke linjekostnader som holdes utenfor. Jeg vil derfor ikke at tallet brukes videre ennå.

Silje

---

</details>
