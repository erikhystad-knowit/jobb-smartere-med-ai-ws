# SV: Ordre eldre enn 45 dager

**Fra:** sander.lie@nordflow.example
**Til:** jonas.aas@nordflow.example, silje.tran@nordflow.example, ragnhild.moen@nordflow.example
**Kopi:** –
**Sendt:** 2026-09-02T13:08:00+02:00
**Emne:** SV: Ordre eldre enn 45 dager

Ny kobling mot kundemaster gir 16,8 mill. totalt. 6,2 mill. har manglende/tvetydig fakturamottaker, 3,4 mill. venter pris/kontraktsavklaring, 2,1 mill. kundetvist og 5,1 mill. ordinært etterslep. Kategoriene er gjensidig utelukkende i filen.

Sander

---

<details>
<summary>Tidligere meldinger i tråden</summary>

**Fra:** ragnhild.moen@nordflow.example  
**Sendt:** 2026-08-28T10:29:00+02:00  
**Til:** jonas.aas@nordflow.example, silje.tran@nordflow.example  
**Emne:** SV: Ordre eldre enn 45 dager

Pilotteamet kjenner 4,1 mill. knyttet til uavklart fakturamottaker, pris eller manglende godkjenning. Resten kan jeg ikke forklare fra kundesiden. Pass på at utsatt fakturering ikke omtales som tap.

Ragnhild

---

**Fra:** jonas.aas@nordflow.example  
**Sendt:** 2026-08-28T08:17:00+02:00  
**Til:** silje.tran@nordflow.example, ragnhild.moen@nordflow.example  
**Emne:** Ordre eldre enn 45 dager

Avstemmingen viser 13,9 mill. i leverte, fakturerbare ordre eldre enn 45 dager. Før vi eskalerer: hvor mye skyldes kundetvist, hvor mye manglende kontraktsdata, og hvor mye er vanlig etterslep?

Jonas

---

</details>
